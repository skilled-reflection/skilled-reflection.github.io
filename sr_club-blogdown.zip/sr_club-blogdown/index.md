---
title: "Skilled Reflection"

---

## Think better. Live better. {.tabset}  

### Clarify
You have something worth living for.
What is it? 
You're working on it, right?

Suppose there's room for improvement. 
If your research paper deserves a second draft,
so do your goals and plans. 

### your purpose
Skilled Reflection is a writing club with purpose: yours. 
Join us.
You'll sharpen your goals,
remove unhelpful activities (ehhem: drop that elective),
and resolve conflicts in your way.

### now.

Not sure if you need this? 
Are you going to die someday? 

Try this: describe yourself in [250 words](self250.html). 

## In the news  

Read about us in the [Psychology Department Bulletin](https://psych.wisc.edu/news/when-personal-experience-meets-psychology-michael-koranda/).

  
