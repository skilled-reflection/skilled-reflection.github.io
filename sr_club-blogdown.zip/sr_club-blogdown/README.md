## Welcome to Skilled Reflection  

1. Curiosity
2. Change
3. Revise and repeat.
