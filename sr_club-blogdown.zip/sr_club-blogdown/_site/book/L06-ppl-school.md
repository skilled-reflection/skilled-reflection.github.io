

<!-- 326 words -->

## Lesson: Goals vs PPL
## "Student vs. School"  


**Task 1. 3m, 40w.**
This is a lesson in curriculum writing.
Imagine a perfect course exists,
designed to teach you
to fulfill your specific ambitions.
 
What are your top 4 goals for
the next 10 years?
you could work on any part of yourself,
move toward any goal you want.
 
list four goals,
Each no longer than 10 words
 
**Task 2. 3m, 40w.**
Your current program requires things your 10 year plan does not.
Courses impose a number of
conditions on your life:
1.  Fixed time: courses
2.  Variable time: assignments
3.  Uncertain time: studying
 
List four objectives, goals, course or program requirements that are
most on your mind right now.
Whether most frustrating, or most critical
to you, even 'impress my professor'.
 
**Task 3. 5m, 50w.**
 
Spell out the intersection between the two lists.
Think of how each goal in the second list
directly influences (or not) your 10 year
objectives.
 
Explore the main ways these two lists relate.
 
For example,
1.  If I don't get a B, I won't keep my scholarship, and will have to
    get a job which will likely lower all my grades.
 
 
**Task 4. 15m, 100w.**
 
 
What is the least you can do toward the course requirements and still achieve your long term goals?
Consider cutting the work from list two,
that doesn't overlap with one.
 
Examples:
 
1.  Graphic design is fun but not necessary. I could drop it and
    still graduate.
2.  If I get a D, I'll still pass, graduate, and be able to start my own
    business.
 
Add 100 more words to your description.
 
**Task 5. 15m, 50w.**
 
Negotiate ways to make direct progress on your first list while fulfilling the second list.
 
For example, my personality class requires a term paper.
To align with my business goal, maybe the professor will let me write
on "personality traits of Entrepreneurs."
 
Add up to 50 words, and revise.
