---
output:
  pdf_document: default
  html_document: default
---

![](figs/title.png)

### Change your thoughts. Change your life.  

honestly believe
the answers to the following
questions are "Yes."  
1.Is there a better version of you?   
2.Are you capable of revising?  
3.Are you ready, now?  
