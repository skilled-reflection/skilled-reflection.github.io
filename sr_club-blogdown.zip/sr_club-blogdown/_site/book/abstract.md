1-what one question and answer best guides each chapter?

## part 1

self-0-q what is food, what i must do in order to have cake, what i most want?
a-food is health: maximum physical energy (fit) and mental energy (wit). cake is motivation, meaning and will to live (pri).

pri-0-q what actions maximize cake in my life?
a-efficient fit and wit maximally used, before death (plan).

bet-0-q what actions result in cake?
a-steps taken now according to my plan (bets) and revision according to bet wins, and failures (CHUD).

ppl-0-q what are ppl?
a-parallel universes dealing with the identical problem set.


## part 2

ed-0 what now?

a-learn all your answers (student), along with other ppl (peers): go to school (ibc).

words-0 what do i study?

a-how to minimize the difference between your pri (words) and data (reality).

(a-how to increase bet wins, and minimize their failures over your time as a student (data).)

revision-0 when am i done?

a-when your plan for bets is according to pris, prepared for CHUD is good enough to bet on (revision): as soon as possible (blitz).

epilogue-0 what is wrong with this book?

a-it is mostly about idealized productivity, because it is written by one instructor obsessed with discipline and science fiction.
