
#words-manifesto-repair  
when listening to invalid speech,
after--repair
1m-gently with gestures  
2m-briefly and clearly with words  
3m-firmly with boundaries  
5m-civilly end conversation and walk away.  

#words-manifesto- dialog / revise / anon  
write what you bet  
revise toward truth  
- to max others' bets

radical anti-ownership of ideas  
- edit for anyone with the authority of your autobiography  
- for the benefit of the OP  
- expecting only feedback  

#words-manifesto- actions  
commit values to bets  
- define self vs cake  
- idea > xref  
- bet > fact > belief > word  
- action > money > words > thoughts  

solutions to problems  
- remove problem src or self from problem.  
- accept that problem comes from other solutions  
- reuse, revise solutions  
- blitz solution  
- eat, sleep better  
- wake up: cold shower, pint of water, work out, deaf/blind hour, spend time with an ugly person  

minimalism; align, revise and keep fit  
- keep hf clean, ready, nearby  
- keep SELF-PLAN minimal    
