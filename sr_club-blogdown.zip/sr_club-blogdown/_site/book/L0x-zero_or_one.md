2021-11-22-2217


## Lesson: 0 or 1
As a human you are endowed with words.
Too much, so.
For a moment, forget those words.

Please answer each question with "0" or "1".
Do not dwell on any one question.
 
1.  Which are you: 0 or 1?
2.  If the person who knew you best guessed your answer,
    what would they report? 0 or 1?
3.  What would you tell them you are?
4.  What would the last dog you encountered say you are?
 
How do you feel about
5.  lunch today?
6.  the chair you are sitting in?
7.  your fingers?
 
8.  Where do you live?
9.  When were you born?
10. What makes this question so simple that you can answer it
    with 0 or 1?
11. Is lying, or hoping, or reminiscing 0, or 1?
12. Have you been telling the truth to these questions?
13. Are you honest with yourself?
 
14. Are you here?
15. Do you know?
16. How do you know?
17. What would it look like if you didn't know?
18. What if you *don't know* if you know?
 
19. What are you certain of?
20. Is this annoying or interesting?
21. Are you ready to use words, yet?
 
22. Imagine you didn't know of language beyond 0 or 1.
    You didn't know a deeper connection with others was possible.
    The chance to respond to the following question is
    your 15 minutes of fame to the universe.
    What is your one bit of say,
    written on the ledger next to your existence, or
    on your tombstone: 0 or 1?
 
23. What's your average score? 0 or 1?
24. Has this been insightful?
 
If you wrote 1 for 24, congratulations.